# Disgruntled retail workers wanted!

Step into the bustling aisles of Retail Therapy, the VR game that places you right into the everyday chaos of retail work! As a new employee at a clothing outlet, your mission is to fulfil customer orders by carefully collecting the right items — or snagging the wrong one in a moment of frustration. It's up to you how you deliver the item too: directly into their hands with care, or as a fast moving projectile aimed directly towards them.

## Unleash your inner frustration

Be wary though! Whilst you race to meet quota, you'll need to keep a vigilant eye out for shoplifters lurking in the aisles, ready to test your observational skills and reaction time. With each shift, the stakes rise as you balance customer satisfaction, the chaos of mixed-up orders, and the thrill of catching a thief. Get ready for an entertaining experience where every day on the job is one you won't want to call in sick for!
